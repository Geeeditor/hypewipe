<?php if($paginator->hasPages()): ?>
    <div class="absolute flex justify-between w-full">
        <!-- Previous Page Link -->
        <?php if($paginator->onFirstPage()): ?>
            <span class="mdi-arrow-left-drop-circle-outline text-[40px] text-gray-500 cursor-default mdi" aria-disabled="true"></span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="mdi-arrow-left-drop-circle-outline text-[40px] hover:text-indigo-800 hover:scale-[1.1] cursor-pointer mdi" aria-label="<?php echo e(__('pagination.previous')); ?>"></a>
        <?php endif; ?>

        <!-- Next Page Link -->
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="mdi-arrow-right-drop-circle-outline text-[40px] hover:text-indigo-800 hover:scale-[1.1] cursor-pointer mdi" aria-label="<?php echo e(__('pagination.next')); ?>"></a>
        <?php else: ?>
            <span class="mdi-arrow-right-drop-circle-outline text-[40px] text-gray-500 cursor-default mdi" aria-disabled="true"></span>
        <?php endif; ?>
    </div>

    
<?php endif; ?>
<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\resources\views\vendor\pagination\paginator.blade.php ENDPATH**/ ?>