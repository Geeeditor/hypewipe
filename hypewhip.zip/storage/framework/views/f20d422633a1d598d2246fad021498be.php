<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <input type="range" class="form-range" <?php echo e($attributes); ?>>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\vendor\orchid\platform\resources\views\fields\range.blade.php ENDPATH**/ ?>