<nav class="d-flex justify-content-center text-nowrap mb-3">
    <div class="bg-body-tertiary rounded overflow-hidden">
        <ul class="nav nav-pills nav-justified d-inline-flex mx-auto px-3 py-2 nav-scroll-bar gap-2">
            <?php echo $navigations; ?>

        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\vendor\orchid\platform\resources\views\layouts\tabMenu.blade.php ENDPATH**/ ?>