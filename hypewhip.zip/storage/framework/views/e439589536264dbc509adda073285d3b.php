<?php echo (new \Orchid\Icons\Icon($html))->setAttributes($data); ?>

<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\vendor\orchid\blade-icons\views\icon.blade.php ENDPATH**/ ?>