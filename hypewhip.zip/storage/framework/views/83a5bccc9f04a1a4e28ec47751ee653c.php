<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\vendor\orchid\platform\resources\views\partials\notification-wrap.blade.php ENDPATH**/ ?>