<?php if($paginator->hasPages()): ?>
    <nav id="pagination-nav" role="navigation" aria-label="Pagination Navigation" class="flex justify-between gap-1">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="place-content-center grid bg-indigo-400 rounded-full w-[20px] h-[20px] scale-[0.95]">
                <span class="fa-arrow-left text-[8px] text-white fa-solid"></span>
            </span>
        <?php else: ?>
            <a rel="prev" href="<?php echo e($paginator->previousPageUrl()); ?>" class="place-content-center grid bg-indigo-900 rounded-full w-[20px] h-[20px] animate-pulse">
                <span class="fa-arrow-left text-[8px] text-white fa-solid"></span>
            </a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a rel="next" href="<?php echo e($paginator->nextPageUrl()); ?>" class="place-content-center grid bg-indigo-900 rounded-full w-[20px] h-[20px] animate-pulse">
                <span class="fa-arrow-right text-[8px] text-white fa-solid"></span>
            </a>
        <?php else: ?>
            <span class="place-content-center grid bg-indigo-400 rounded-full w-[20px] h-[20px] scale-[0.95]">
                <span class="fa-arrow-right text-[8px] text-white fa-solid"></span>
            </span>
        <?php endif; ?>
    </nav>

  
<?php endif; ?>
<?php /**PATH C:\Users\Gee Editor\OneDrive\Documents\Projects\hypewhip\resources\views\vendor\pagination\simple-tailwind.blade.php ENDPATH**/ ?>