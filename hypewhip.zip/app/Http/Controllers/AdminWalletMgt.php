<?php

namespace App\Http\Controllers;

use App\Models\AdminWallets;
use Illuminate\Http\Request;

class AdminWalletMgt extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(AdminWallets $adminWallets)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(AdminWallets $adminWallets)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, AdminWallets $adminWallets)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(AdminWallets $adminWallets)
    {
        //
    }
}
