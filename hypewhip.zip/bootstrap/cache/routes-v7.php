<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/biscolab-recaptcha/validate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H9eukQiMOmECcI1H',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fSLfpZ5L4P2hLch8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fqDbnWU5lXdEfkmm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/quests/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quest.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/quests/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quest.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wallet' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wallet',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tasks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tasks',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tasks/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tasks.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/withdraw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'withdraw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/withdraw/process' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'withdraw.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wallet/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wallet.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'notification',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wallet/topup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wallet.topup',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wallet/topup/process' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wallet.topup.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/change' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update.password',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UhkOHMk2C51HBLue',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NphvKTjCslbFmUH9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/verify-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.notice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verification-notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/confirm-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2MZZuEH8cWAI0FEB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/async' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.async',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/systems/files' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.files.upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/systems/media' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.files.media',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/systems/files/sort' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.files.sort',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/systems/relation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.relation',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/systems/sorting' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.sorting',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/api/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.api.notifications',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'platform.login.auth',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.login.lock',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/switch-logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'platform.switch.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|dmin/(?|w(?|allet/edit/([^/]++)(?:/(saveWallet))?(*:61)|ithdrawal(?|(?:/(0))?(*:89)|/update/([^/]++)(?:/(updateStatus))?(*:132)))|s(?|earch/([^/]++)(?:/(changeSearchType|compact))?(*:192)|ystems/files/(?|([^/]++)(*:224)|post/([^/]++)(*:245)))|listener/([^/]++)/([^/]++)(*:281)|notifications(?:/([^/]++)(?:/(maskNotification|markAllAsRead|removeAll|unreadNotification))?)?(*:383)|main(?:/(0))?(*:404)|create\\-wallet(?:/(submitForm))?(*:444)|view\\-wallet(?:/(showToast|deleteWallet))?(*:494)|deposit(?|(?:/(0))?(*:521)|/update/([^/]++)(?:/(updateStatus))?(*:565))|users(?|/(?|topup(?|(?:/(0))?(*:603)|/([^/]++)(?:/(topup))?(*:633))|([^/]++)/edit(?:/(save|remove|loginAs))?(*:682)|create(?:/(save|remove|loginAs))?(*:723))|(?:/(loadUserOnOpenModal|saveUser|remove))?(*:775))|quest/(?|list(?:/(deleteQuest))?(*:816)|view/update/([^/]++)(?:/(0))?(*:853))|profile(?:/(save|changePassword))?(*:896)|roles(?|/(?|([^/]++)/edit(?:/(save|remove))?(*:948)|create(?:/(save|remove))?(*:981))|(?:/(0))?(*:999))|example(?|(?:/(showToast))?(*:1035)|s/(?|form/(?|fields(?:/(buttonClickProcessing))?(*:1092)|a(?|dvanced(?:/(0))?(*:1121)|ctions(?:/(buttonClickProcessing|export))?(*:1172))|editors(?:/(0))?(*:1198))|layouts(?:/(0))?(*:1224)|grid(?:/(0))?(*:1246)|c(?|harts(?:/(0))?(*:1273)|ards(?:/(showToast))?(*:1303))))|(.*)(*:1319))|vailable\\-wallets/([^/]++)(*:1355))|/reset\\-password/([^/]++)(*:1390)|/verify\\-email/([^/]++)/([^/]++)(*:1431)|/storage/(.*)(*:1453))/?$}sDu',
    ),
    3 => 
    array (
      61 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.wallet.edit',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'adminWallet',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      89 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawal',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawal.update',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.search',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'query',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      224 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.files.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.files.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      281 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.async.listener',
          ),
          1 => 
          array (
            0 => 'screen',
            1 => 'layout',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.notifications',
            'id' => NULL,
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.main',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      444 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.wallet',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      494 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.wallet.view',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposit',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      565 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposit.view',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      603 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.topup',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.topup.edit',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      682 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.users.edit',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'user',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      723 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.users.create',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.users',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      816 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quest.list',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quest.update',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      896 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.profile',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.roles.edit',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.roles.create',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      999 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.systems.roles',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1035 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1092 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.fields',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.advanced',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.actions',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.editors',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1224 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.layouts',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1246 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.grid',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1273 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.charts',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.example.cards',
            'method' => NULL,
          ),
          1 => 
          array (
            0 => 'method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'platform.generated::MXc6Q60W3I6GIdq2',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1355 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'available-wallets.delete',
          ),
          1 => 
          array (
            0 => 'walletAddress',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.verify',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'hash',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::H9eukQiMOmECcI1H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'biscolab-recaptcha/validate',
      'action' => 
      array (
        'uses' => 'Biscolab\\ReCaptcha\\Controllers\\ReCaptchaController@validateV3',
        'controller' => 'Biscolab\\ReCaptcha\\Controllers\\ReCaptchaController@validateV3',
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::H9eukQiMOmECcI1H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fSLfpZ5L4P2hLch8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:863:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\Users\\\\Gee Editor\\\\OneDrive\\\\Documents\\\\Projects\\\\hypewhip\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"000000000000036f0000000000000000";}}',
        'as' => 'generated::fSLfpZ5L4P2hLch8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fqDbnWU5lXdEfkmm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:59:"function () {
    return \\redirect()->route(\'dashboard\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003be0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fqDbnWU5lXdEfkmm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.wallet.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/wallet/edit/{adminWallet}/{method?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'web',
        ),
        'uses' => 'App\\Orchid\\Screens\\EditWalletScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\EditWalletScreen',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'admin.wallet.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'saveWallet',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quest.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quests/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\QuestController@create',
        'controller' => 'App\\Http\\Controllers\\QuestController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'admin.quest.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quest.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/quests/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
          2 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\QuestController@store',
        'controller' => 'App\\Http\\Controllers\\QuestController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'admin.quest.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wallet' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wallet',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@viewWallet',
        'controller' => 'App\\Http\\Controllers\\HomeController@viewWallet',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wallet',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tasks' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tasks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@quest',
        'controller' => 'App\\Http\\Controllers\\HomeController@quest',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'tasks',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tasks.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tasks/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@questStore',
        'controller' => 'App\\Http\\Controllers\\HomeController@questStore',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'tasks.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'withdraw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'withdraw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@withdraw',
        'controller' => 'App\\Http\\Controllers\\HomeController@withdraw',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'withdraw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'withdraw.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'withdraw/process',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@withdrawStore',
        'controller' => 'App\\Http\\Controllers\\HomeController@withdrawStore',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'withdraw.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@viewProfile',
        'controller' => 'App\\Http\\Controllers\\HomeController@viewProfile',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wallet.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'wallet/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\UserWalletController@addWallet',
        'controller' => 'App\\Http\\Controllers\\UserWalletController@addWallet',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wallet.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'notification' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'notification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@userNotification',
        'controller' => 'App\\Http\\Controllers\\HomeController@userNotification',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'notification',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wallet.topup' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wallet/topup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@topUp',
        'controller' => 'App\\Http\\Controllers\\HomeController@topUp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wallet.topup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wallet.topup.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'wallet/topup/process',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@topUpStore',
        'controller' => 'App\\Http\\Controllers\\HomeController@topUpStore',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wallet.topup.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update.password' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'password/change',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@changePassword',
        'controller' => 'App\\Http\\Controllers\\HomeController@changePassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'update.password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'available-wallets.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'available-wallets/{walletAddress}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\UserWalletController@deleteAvailableWallet',
        'controller' => 'App\\Http\\Controllers\\UserWalletController@deleteAvailableWallet',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'available-wallets.delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'profile/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\ProfileController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'profile/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProfileController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisteredUserController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisteredUserController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UhkOHMk2C51HBLue' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisteredUserController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisteredUserController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UhkOHMk2C51HBLue',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NphvKTjCslbFmUH9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NphvKTjCslbFmUH9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordResetLinkController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'controller' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\NewPasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.notice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'verify-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\EmailVerificationPromptController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Auth\\EmailVerificationPromptController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.notice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'verify-email/{id}/{hash}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'signed',
          3 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\VerifyEmailController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Auth\\VerifyEmailController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'email/verification-notification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\EmailVerificationNotificationController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\EmailVerificationNotificationController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'confirm-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@show',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2MZZuEH8cWAI0FEB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'confirm-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmablePasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2MZZuEH8cWAI0FEB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordController@update',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Auth\\AuthenticatedSessionController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\IndexController@index',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\IndexController@index',
        'as' => 'platform.index',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:310:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:92:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail->push(\\__(\'Home\'), \\route(\'platform.index\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003500000000000000000";}";s:4:"hash";s:44:"Hfq9aEq2kI6UIxXK2OhMFjv8OXubEbK2r87kVwF9EGo=";}}',
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/search/{query}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Screens\\SearchScreen@__invoke',
        'controller' => 'Orchid\\Platform\\Http\\Screens\\SearchScreen',
        'as' => 'platform.search',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:360:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:141:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, string $query) => $trail->parent(\'platform.index\')
        ->push(\\__(\'Search\'))
        ->push($query)";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000034f0000000000000000";}";s:4:"hash";s:44:"sCztekc9spYySMIJOq99sC2KPsIswl6xEcaBXKXINpg=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'changeSearchType|compact',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.async' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/async',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AsyncController@load',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AsyncController@load',
        'as' => 'platform.async',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.async.listener' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/listener/{screen}/{layout}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AsyncController@listener',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AsyncController@listener',
        'as' => 'platform.async.listener',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.files.upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/systems/files',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@upload',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@upload',
        'as' => 'platform.systems.files.upload',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.files.media' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/systems/media',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@media',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@media',
        'as' => 'platform.systems.files.media',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.files.sort' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/systems/files/sort',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@sort',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@sort',
        'as' => 'platform.systems.files.sort',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.files.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/systems/files/{id}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@destroy',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@destroy',
        'as' => 'platform.systems.files.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.files.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/systems/files/post/{id}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@update',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\AttachmentController@update',
        'as' => 'platform.systems.files.update',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.relation' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/systems/relation',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\RelationController@view',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\RelationController@view',
        'as' => 'platform.systems.relation',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.sorting' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/systems/sorting',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\SortableController@saveSortOrder',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\SortableController@saveSortOrder',
        'as' => 'platform.systems.sorting',
        'namespace' => NULL,
        'prefix' => 'admin/systems',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.notifications' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/notifications/{id?}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Screens\\NotificationScreen@__invoke',
        'controller' => 'Orchid\\Platform\\Http\\Screens\\NotificationScreen',
        'as' => 'platform.notifications',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:333:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:114:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail->parent(\'platform.index\')
            ->push(\\__(\'Notifications\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003900000000000000000";}";s:4:"hash";s:44:"b4X5asXmdyb2sIgxgIusAqzKzGDCwGwkHEgbp4nrbWs=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'maskNotification|markAllAsRead|removeAll|unreadNotification',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.api.notifications' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/api/notifications',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Screens\\NotificationScreen@unreadNotification',
        'controller' => 'Orchid\\Platform\\Http\\Screens\\NotificationScreen@unreadNotification',
        'as' => 'platform.api.notifications',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.generated::MXc6Q60W3I6GIdq2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/{fallbackPlaceholder}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\IndexController@fallback',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\IndexController@fallback',
        'as' => 'platform.generated::MXc6Q60W3I6GIdq2',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@showLoginForm',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@showLoginForm',
        'as' => 'platform.login',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.login.auth' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
          2 => 'throttle:60,1',
        ),
        'uses' => '\\Orchid\\Platform\\Http\\Controllers\\LoginController@login',
        'controller' => '\\Orchid\\Platform\\Http\\Controllers\\LoginController@login',
        'as' => 'platform.login.auth',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.login.lock' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lock',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@resetCookieLockMe',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@resetCookieLockMe',
        'as' => 'platform.login.lock',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/switch-logout',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@switchLogout',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@switchLogout',
        'as' => 'platform.',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.switch.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/switch-logout',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@switchLogout',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@switchLogout',
        'as' => 'platform.switch.logout',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/logout',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@logout',
        'controller' => 'Orchid\\Platform\\Http\\Controllers\\LoginController@logout',
        'as' => 'platform.logout',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.main' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/main/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\PlatformScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\PlatformScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.main',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.wallet' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/create-wallet/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\CreateWalletScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\CreateWalletScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.wallet',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'submitForm',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.wallet.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/view-wallet/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\ViewWalletScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\ViewWalletScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.wallet.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'showToast|deleteWallet',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/deposit/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\UserDepositScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\UserDepositScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.deposit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposit.view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/deposit/update/{id}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\UserViewDepositScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\UserViewDepositScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.deposit.view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'updateStatus',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawal' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/withdrawal/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\UserWithdrawalScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\UserWithdrawalScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.withdrawal',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawal.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/withdrawal/update/{id}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\UpdateUserWithdrawalScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\UpdateUserWithdrawalScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.withdrawal.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'updateStatus',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.topup' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/users/topup/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\TopupUser@__invoke',
        'controller' => 'App\\Orchid\\Screens\\TopupUser',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.users.topup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.topup.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/users/topup/{id}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\TopupUserEdit@__invoke',
        'controller' => 'App\\Orchid\\Screens\\TopupUserEdit',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.users.topup.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'topup',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quest.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/quest/list/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\QuestListScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\QuestListScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.quest.list',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'deleteQuest',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quest.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/quest/view/update/{id}/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\UpdateQuestScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\UpdateQuestScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'admin.quest.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/profile/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\User\\UserProfileScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\User\\UserProfileScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:360:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:141:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.index\')
        ->push(\\__(\'Profile\'), \\route(\'platform.profile\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003960000000000000000";}";s:4:"hash";s:44:"JabbaBEM5LHibb/0cRhr3YxVe6xO1EnxkYUx/WzB09U=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'save|changePassword',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/users/{user}/edit/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\User\\UserEditScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\User\\UserEditScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.users.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:171:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, $user) => $trail
        ->parent(\'platform.systems.users\')
        ->push($user->name, \\route(\'platform.systems.users.edit\', $user))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003aa0000000000000000";}";s:4:"hash";s:44:"rlcA4meEP4/LxJi/V4c5sZlT6+TQzpRNJDU6trxEt6I=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'save|remove|loginAs',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/users/create/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\User\\UserEditScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\User\\UserEditScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.users.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:380:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:161:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.systems.users\')
        ->push(\\__(\'Create\'), \\route(\'platform.systems.users.create\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003ae0000000000000000";}";s:4:"hash";s:44:"UJISOCe7xtXzX00T0dvPnElH8qkXOjFrmLi8cfHJXqg=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'save|remove|loginAs',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/users/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\User\\UserListScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\User\\UserListScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:364:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:145:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.index\')
        ->push(\\__(\'Users\'), \\route(\'platform.systems.users\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003af0000000000000000";}";s:4:"hash";s:44:"CfhWyvx396Kwsh8EJxBAxt/JfzIw7jI1gwjk0dsEynw=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'loadUserOnOpenModal|saveUser|remove',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/roles/{role}/edit/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\Role\\RoleEditScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Role\\RoleEditScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.roles.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:390:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:171:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail, $role) => $trail
        ->parent(\'platform.systems.roles\')
        ->push($role->name, \\route(\'platform.systems.roles.edit\', $role))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003b20000000000000000";}";s:4:"hash";s:44:"nLKWCQv7mh8uizv7x6pXukNkSVLalctwybXBTDnza4w=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'save|remove',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/roles/create/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\Role\\RoleEditScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Role\\RoleEditScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.roles.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:380:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:161:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.systems.roles\')
        ->push(\\__(\'Create\'), \\route(\'platform.systems.roles.create\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003b30000000000000000";}";s:4:"hash";s:44:"wcCyhzgIoAh0r0XFj1cKviH3FP5+c8R7xIeWH/PaC+Y=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'save|remove',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.systems.roles' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/roles/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\Role\\RoleListScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Role\\RoleListScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.systems.roles',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:364:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:145:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.index\')
        ->push(\\__(\'Roles\'), \\route(\'platform.systems.roles\'))";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003ac0000000000000000";}";s:4:"hash";s:44:"+pMwuSlmW4bnkH+vYplV1uxxXumoLnixOxvHwfncA+0=";}}',
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/example/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
          3 => 'breadcrumbs',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'Tabuna\\Breadcrumbs\\BreadcrumbsMiddleware' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:334:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:115:"fn (\\Tabuna\\Breadcrumbs\\Trail $trail) => $trail
        ->parent(\'platform.index\')
        ->push(\'Example Screen\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003b50000000000000000";}";s:4:"hash";s:44:"PCBw4NCCoxyGtNcP6cfTyMc6XdSMAP8VCdPLIyEbjG8=";}}',
      ),
      'wheres' => 
      array (
        'method' => 'showToast',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.fields' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/form/fields/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleFieldsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleFieldsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.fields',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'buttonClickProcessing',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.advanced' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/form/advanced/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleFieldsAdvancedScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleFieldsAdvancedScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.advanced',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.editors' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/form/editors/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleTextEditorsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleTextEditorsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.editors',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.actions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/form/actions/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleActionsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleActionsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.actions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'buttonClickProcessing|export',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.layouts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/layouts/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleLayoutsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleLayoutsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.layouts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.grid' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/grid/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleGridScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleGridScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.grid',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.charts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/charts/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleChartsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleChartsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.charts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => '0',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'platform.example.cards' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
      ),
      'uri' => 'admin/examples/cards/{method?}',
      'action' => 
      array (
        'domain' => '',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'platform',
          2 => 'cache.headers:private;must_revalidate;etag',
        ),
        'uses' => 'App\\Orchid\\Screens\\Examples\\ExampleCardsScreen@__invoke',
        'controller' => 'App\\Orchid\\Screens\\Examples\\ExampleCardsScreen',
        'namespace' => NULL,
        'prefix' => '/admin/',
        'where' => 
        array (
        ),
        'as' => 'platform.example.cards',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'method' => 'showToast',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:4:{s:6:"driver";s:5:"local";s:4:"root";s:76:"C:\\Users\\Gee Editor\\OneDrive\\Documents\\Projects\\hypewhip\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000003470000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
